public class Die{
   private int faceValue = 0;
   public void roll(){
      ;
   }
   public int getFaceValue(){
      return faceValue;
   }
}