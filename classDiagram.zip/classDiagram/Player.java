public class Player{
   private String name = "";
   private Scorecard scorecard;
   public void rollDice(){
      ;
   }
   public void selectCategory(Category category){
      ;
   }
}