import java.util.*;
public class Scorecard{
   private List<Category> scoreList;
   private int overallScore = 0;
   public int calculateCategoryScore(Category category, List<Die> dice){
      return overallScore;
   }
   public boolean isCategoryAvailable(Category category){
      return true;
   }
}