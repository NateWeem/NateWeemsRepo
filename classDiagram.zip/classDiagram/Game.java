import java.util.*;
public class Game{
   private List<Player> players;
   private Player currentPlayer;
   private List<Die> dice;
   public void startGame(){
      ;
   }
   public void nextTurn(){
      ;
   }
   public boolean isGameOver(){
      return true;
   }
   public void declareWinner(){
      ;
   }
}