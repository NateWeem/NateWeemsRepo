import java.util.*;
abstract class Category{
   private String name = "";
   private int value = 0;
   abstract class isMatch{
      abstract boolean isMatch(List<Die> dice);
   }
}